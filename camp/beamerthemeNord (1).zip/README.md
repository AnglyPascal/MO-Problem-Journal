# beamerthemeNord

A simple beamer theme using [Nord](https://www.nordtheme.com/) color theme.

## Usage 

See [beamerthemeNord.pdf](./beamerthemeNord.pdf) or [beamerthemeNord.tex](./beamerthemeNord.tex)

## Maintainer

Junwei Wang (i.junwei.wang@gmail.com)

## License

This work may be distributed and/or modified under the conditions of the LaTeX Project Public License, either version 1.3c of this license or (at your option) any later version. The latest version of this license is in http://www.latex-project.org/lppl.txt .